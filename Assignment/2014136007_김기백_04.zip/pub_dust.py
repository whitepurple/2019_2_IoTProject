# -*- coding: utf-8 -*- 
import paho.mqtt.client as mqtt
import random
import time

def getMsg():	#미세먼지 농도를 받아오는 함수
    msg = str(random.randrange(10, 100))	# 랜덤으로 수를 생성하여 반환
    return msg                

def on_connect(client, userdata, flags, rc):	#초기 연결 시 불리는 함수
    print("Connected with result code " + str(rc))

def on_publish(client, userdata, mid):	#메시지 발행 완료 시 불리는 함수
    print("Fine Dust message published: "+str(t))

mqttc = mqtt.Client()
mqttc.on_connect = on_connect
mqttc.on_publish = on_publish
mqttc.connect("localhost")
mqttc.loop_start()

try:
    while True:
        t = getMsg() 	#무한루프 안에서 메세지 발행을 반복
        (result, m_id) = mqttc.publish("home/dust", t)
        time.sleep(2)
        
except KeyboardInterrupt:
    print("Finished!")
    mqttc.loop_stop()
    mqttc.disconnect()