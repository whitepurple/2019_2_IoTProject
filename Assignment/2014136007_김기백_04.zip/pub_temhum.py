# -*- coding: utf-8 -*- 
import paho.mqtt.client as mqtt
import random
import time


def getTem():   #온도를 받아오는 함수
    msg = str(random.randrange(20, 35))
    return msg                

def getHum():   #습도를 받아오는 함수
    msg = str(random.randrange(30, 95))
    return msg                

def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))

def on_publish(client, userdata, mid):  #온습도 메세지를 발행
    print "Message published",

mqttc = mqtt.Client()
mqttc.on_connect = on_connect
mqttc.on_publish = on_publish
mqttc.connect("localhost")
mqttc.loop_start()

try:
    while True:
        t = getTem()        #온습도를 받아와서 발행
        h = getHum()
        (result, m_id) = mqttc.publish("home/temperature", t)
        (result, m_id) = mqttc.publish("home/humidity", h)
        print("Temperature : {}, Humidity : {}".format(t,h))        
        time.sleep(2)

        
except KeyboardInterrupt:
    print("Finished!")
    mqttc.loop_stop()
    mqttc.disconnect()


