# -*- coding: utf-8 -*- 
import paho.mqtt.client as mqtt
import time

lst = [0,0,0]   #연속3번의 미세먼지 농도 저장
point = 2       #미세먼지 농도 저장 인덱스
tem=0       #온도
hum=0       #습도
#불쾌지수 값에 따른 단계
THI_Level = ("VeryHigh","High","Normal","Fine")

def getpoint(): #미세먼지 농도 저장 인덱스 반환
    global point
    point = (point+1)%3 #하나씩 증가
    return point

def on_connect(client, userdata, flags, rc):
    print("connected with result code " + str(rc))
    client.subscribe("home/temperature") #세 개의 메세지 구독
    client.subscribe("home/humidity")
    client.subscribe("home/dust")
def on_publish(client, userdata, mid):
    return True
def on_message(client, userdata, msg):
    topic = (str(msg.topic))[5:]    #home/부분을 제외하고 받아옴
    msg = str(msg.payload)
    if topic == "dust": #미세먼지 메세지일 때
        global lst
        i = getpoint()
        lst[i] = int(msg)   #순차적으로 하나씩 입력
        if (lst[0]>50 and lst[1]>50 and lst[2]>50):
            dustFine = False    #모두 나쁘면 False
        else:
            dustFine = True
        print("Fine Dust : " + str(dustFine))
    #상태에 따라 ON, OFF 메세지 발행
        (result, m_id) = client.publish("home/airpurifier", "OFF" if dustFine else "ON")
    elif topic == "temperature":    #온도일 때 
        global tem
        tem = int(msg)  #온도 저장
        printTHI()      #불쾌지수 계산 및 출력
    elif topic == "humidity":   #습도일 때
        global hum
        hum = int(msg)  #습도 저장
        printTHI()      #불쾌지수 계산 및 출력
    
def printTHI(): #불쾌지수 계산 및 출력
    #수식에 따라 불쾌지수 계산
    THI = (9*tem)/5.0 - 0.55*(1-hum/100.0)*((9*tem)/5.0-26)+32
    #불쾌지수에 따라 단계 출력
    if THI > 80.0:
        THI_index = 0   #조건에 따라 ON 메세지 발행
        (result, m_id) = client.publish("home/airconditioner", "ON")
    elif THI > 75.0:
        THI_index = 1
        (result, m_id) = client.publish("home/airconditioner", "ON")
    elif THI > 68.0:
        THI_index = 2
    else:
        THI_index = 3   #조건에 따라 OFF 메세지 발행
        (result, m_id) = client.publish("home/airconditioner", "OFF")
    print(str(int(THI)) + " (" + str(THI_Level[THI_index]) + ") \
[tempreture: "+str(tem)+" humidity: "+str(hum)+"]")
    
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.on_publish = on_publish
client.connect("localhost")

try:
    client.loop_forever()
except KeyboardInterrupt:
    print("Finished!")
    client.unsubscribe(["home/temperature","home/humidity","home/dust"])
    client.disconnect()

