# -*- coding: utf-8 -*- 
import paho.mqtt.client as mqtt

def on_connect(client, userdata, flags, rc):
    print("connected with result code " + str(rc))
    client.subscribe("home/airpurifier")	#구독
        
def on_message(client, userdata, msg):
    print("Air Purifier " + str(msg.payload))	#수신한 신호 출력

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.connect("localhost")

try:
    client.loop_forever()
except KeyboardInterrupt:
    print("Finished!")
    client.unsubscribe(["home/airpurifier"])
    client.disconnect()

