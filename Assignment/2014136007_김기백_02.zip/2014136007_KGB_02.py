import RPi.GPIO as gpio
import spidev
import time

spi = spidev.SpiDev()
spi.open(0,0)
spi.max_speed_hz = 976000

led_r = 26
led_y = 19
led_g = 13

gpio.setmode(gpio.BCM)
gpio.setup(led_r, gpio.OUT)
gpio.setup(led_y, gpio.OUT)
gpio.setup(led_g, gpio.OUT)

def readChannel(channel):
	adc = spi.xfer2([1, (8 + channel) << 4, 0])
	adc_out = ((adc[1] & 3) << 8) + adc[2]
	return adc_out
	
def convert2volts(data, places):
	volts = (data * 3.3) / float(1023)
	volts = round(volts, places)
	return volts
	
try:
	while True:
		light_level = readChannel(0)
		light_volts = convert2volts(light_level, 2)
		
		print("Light: %d (%f V)" %(light_level, light_volts),end=' ')
		gpio.output(led_g,False)
		gpio.output(led_y,False)
		gpio.output(led_r,False)

		if light_level > 200:
			gpio.output(led_g,True)
			print("Green")
		elif light_level > 80:
			gpio.output(led_y,True)
			print("Yellow")
		else:
			gpio.output(led_r,True)
			print("Red")
		
		time.sleep(0.5)
		
except KeyboardInterrupt:
	print("Finished")
	spi.close()